<?php $__env->startSection('container'); ?>
    <div class="col-12">

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <?php if($berkas->jalur != null): ?>
                    <h5 class="card-title mt-3 mb-0">Data Berkas</h5>
                    <p className="text-gray-500 font-medium ">Unggah foto menggunakan seragam asal sekolah,
                        rapi, wajah tampak jelas dan foto akta kelahiran dengan ketentuan tulisan tampak jelas
                        dan bisa terbaca dengan baik.<b>Ukuran maksimal file adalah 2 MB</b> </p>
                    <form class="row g-3" action="<?php echo e(route('dashboard.data-berkas.update')); ?>" method="post"
                        enctype="multipart/form-data" class="needs-validation" novalidate>
                        <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="col-sm-12 col-md-6">
                            <label for="foto_siswa" class="form-label">Foto Siswa</label>
                            <input class="form-control" type="file" id="foto_siswa" onchange="previewImageSiswa()"
                                accept="image/*" name="foto_siswa" class="<?php $__errorArgs = ['foto_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['foto_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <?php if($berkas->foto_siswa): ?>
                                <img src="<?php echo e(asset($berkas->foto_siswa)); ?>" alt="" class="img-fluid col-sm-6 mt-4">
                            <?php else: ?>
                                <img class="img-preview-siswa img-fluid mb-3 col-sm-6 mt-4">
                            <?php endif; ?>
                        </div>

                        <div class="col-sm-12 col-md-6">
                            <label for="formFile" class="form-label">Foto Kartu Keluarga</label>
                            <input class="form-control" type="file" id="foto_akte" onchange="previewImageAkte()"
                                accept="image/*" name="foto_akte" class="<?php $__errorArgs = ['foto_akte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['foto_akte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <?php if($berkas->foto_akte): ?>
                                <img src="<?php echo e(asset($berkas->foto_akte)); ?>" alt="" class="img-fluid col-sm-6 mt-4">
                            <?php else: ?>
                                <img class="img-preview-akte img-fluid mb-3 col-sm-6 mt-4">
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary mt-4 py-2 rounded-2">
                            Simpan Perubahan
                        </button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-danger mt-4 mb-0" role="alert">
                        <i class="bi bi-exclamation-circle"></i>
                        Silahkan memilih jalur pendaftaran terlebih dahulu! <a href="<?php echo e(route('dashboard.siswa')); ?>">Klik
                            disini</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function previewImageSiswa() {
            const foto_siswa = document.querySelector("#foto_siswa");
            const imgPreviewSiswa = document.querySelector(".img-preview-siswa");

            imgPreviewSiswa.style.display = 'block';

            const oFReader = new FileReader();
            oFReader.readAsDataURL(foto_siswa.files[0]);

            oFReader.onload = function(oFREvent) {
                imgPreviewSiswa.src = oFREvent.target.result;
            }
        }

        function previewImageAkte() {
            const foto_akte = document.querySelector("#foto_akte");
            const imgPreviewAkte = document.querySelector(".img-preview-akte");

            imgPreviewAkte.style.display = 'block';

            const oFReader = new FileReader();
            oFReader.readAsDataURL(foto_akte.files[0]);

            oFReader.onload = function(oFREvent) {
                imgPreviewAkte.src = oFREvent.target.result;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Developments\PROGRAMMING\_project-2023\ppdb-min\server\resources\views/student/data-berkas.blade.php ENDPATH**/ ?>