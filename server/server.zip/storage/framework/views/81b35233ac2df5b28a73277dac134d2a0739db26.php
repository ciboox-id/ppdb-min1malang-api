<?php $__env->startSection('container'); ?>
    <section class="section dashboard">
        <div class="row">
            <!-- Left side columns -->
            <div class="col-lg-12">
                <div class="row">

                    <!-- Card three -->
                    
                    <div class="col-xxl-4 col-md-6">
                        <div class="card info-card register-card">
                            <div class="filter">
                                <a class="icon" href="#" data-bs-toggle="dropdown">
                                    <i class="bi bi-three-dots"></i>
                                </a>
                            </div>

                            <div class="card-body">
                                <h5 class="card-title"></h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-person-fill"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php echo e(count($users)); ?></h6>
                                        <span class="text-muted small pt-2 ps-1">Jumlah Pendaftar</span>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End jumlah pendaftar Card -->

                    
                    <div class="col-xxl-4 col-md-6">
                        <div class="card info-card incomplete-card">

                            <div class="filter">
                                <a class="icon" href="#" data-bs-toggle="dropdown">
                                    <i class="bi bi-three-dots"></i>
                                </a>
                            </div>

                            <div class="card-body">
                                <h5 class="card-title"></h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-file-earmark-text-fill"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php echo e($incomplete); ?></h6>
                                        <span class="text-muted small pt-2 ps-1">Belum Lengkap</span>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Revenue Card -->

                    <!-- Customers Card -->
                    <div class="col-xxl-4 col-xl-12">
                        <div class="card info-card complete-card">
                            <div class="filter">
                                <a class="icon" href="#" data-bs-toggle="dropdown">
                                    <i class="bi bi-three-dots"></i>
                                </a>
                            </div>

                            <div class="card-body">
                                <h5 class="card-title"></h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-file-earmark-text-fill"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php echo e($complete); ?></h6>
                                        <span class="text-muted small pt-2 ps-1">Sudah lengkap</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Customers Card -->

                    
                    <div class="col-12">
                        <div class="card table-student overflow-auto">
                            <div class="card-body">
                                <h5 class="card-title-table">Data Pendaftar</h5>
                                <?php if(session()->has('successDeleteStudent')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <?php echo e(session('successDeleteStudent')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert"
                                            aria-label="Close"></button>
                                    </div>
                                <?php endif; ?>
                                <?php if(session()->has('errorStudent')): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <?php echo e(session('errorStudent')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert"
                                            aria-label="Close"></button>
                                    </div>
                                <?php endif; ?>

                                <table class="table table-borderless datatable">
                                    <thead>
                                        <tr>
                                            <th scope="col">No.</th>
                                            <th scope="col">Nama</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Jalur</th>
                                            <th scope="col">Status Berkas</th>
                                            <th scope="col">Status Verifikasi</th>
                                            <th scope="col">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($users) > 0): ?>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                    <td><?php echo e($user->nama_lengkap); ?></td>
                                                    <td><?php echo e($user->email); ?></td>
                                                    <td style="text-transform: capitalize"><?php echo e($user->jalur); ?></td>
                                                    <td>
                                                        <?php if(is_null($user->foto_akte) && is_null($user->foto_siswa)): ?>
                                                            <span class="badge rounded-pill status-danger">Kurang</span>
                                                        <?php else: ?>
                                                            <span class="badge rounded-pill status">Lengkap</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if(!$user->is_verif): ?>
                                                            <span class="badge rounded-pill status-danger">Belum
                                                                terverfikasi</span>
                                                        <?php else: ?>
                                                            <span class="badge rounded-pill status">Sudah
                                                                terverfikasi</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="d-flex">
                                                        <div class="me-2">
                                                            <a class="badge rounded-pill bg-success badge-custom btn-aksi"
                                                                href="<?php echo e(route('dashboard.data-siswa.detail', ['user' => $user->email])); ?>">
                                                                <i class="bi bi-eye-fill"></i>
                                                                Lihat data
                                                            </a>
                                                        </div>
                                                        

                                                        <div>
                                                            <form action="<?php echo e(route('dashboard.data-siswa.delete', ['student' => $user->id])); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button class="badge rounded-pill bg-danger badge-custom btn-aksi">
                                                                    <i class="bi bi-trash"></i>
                                                                    Hapus
                                                                </button>
                                                            </form>
                                                        </div>

                                                        
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td>Belum ada data siswa</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div><!-- End Recent Sales -->

                </div>
            </div><!-- End Left side columns -->
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Developments\PROGRAMMING\_project-2023\ppdb-min\server\resources\views/dashboard.blade.php ENDPATH**/ ?>