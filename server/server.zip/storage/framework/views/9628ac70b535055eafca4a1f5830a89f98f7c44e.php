<?php $__env->startSection('container'); ?>
    <div class="col-12">

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <div class="d-flex">
                    <a href="<?php echo e(route('dashboard.data-siswa')); ?>" class="back btn btn-primary me-3"> Kembali</a>
                    <?php if($user->is_verif): ?>
                        <form action="<?php echo e(route('inverifikasi', ['user' => $user->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="back btn btn-danger" data-bs-target="#staticBackdrop">
                                Batal Verifikasi
                            </button>
                        </form>
                    <?php else: ?>
                        <button type="button" class="back btn btn-info" data-bs-toggle="modal"
                            data-bs-target="#staticBackdrop">
                            Verifikasi data
                        </button>
                    <?php endif; ?>
                    <form action="<?php echo e(route('dashboard.password-reset', ['user' => $user->id])); ?>" method="post"
                        class="ms-3">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="back btn btn-warning">
                            Reset Password
                        </button>
                    </form>

                </div>

                <h5 class="card-title">Identitas diri</h5>
                <form class="row g-3">
                    <div class="col-sm-12 col-md-6">
                        <label for="inputNanme4" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" id="inputNanme4" value="<?php echo e($user->nama_lengkap); ?>"
                            disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputEmail4" class="form-label">Anak ke</label>
                        <input type="text" class="form-control" value="<?php echo e($user->anak_ke); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputPassword4" class="form-label">Jenis Kelamin</label>
                        <input type="text" class="form-control" value="<?php echo e($user->jenis_kelamin); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">NISN</label>
                        <input type="text" class="form-control" id="inputAddress" value="<?php echo e($user->nisn); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Golongan Darah</label>
                        <input type="text" class="form-control" id="inputAddress" value="<?php echo e($user->gol_darah); ?> "
                            disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Asal Sekolah</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->school->asal_sekolah); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Tempat Lahir</label>
                        <input type="text" class="form-control" id="inputAddress" value="<?php echo e($user->tempat_lahir); ?>"
                            disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Nama Sekolah</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->school->nama_sekolah); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Tanggal Lahir</label>
                        <input type="text" class="form-control" id="inputAddress" value="<?php echo e($user->tanggal_lahir); ?>"
                            disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">NPSN</label>
                        <input type="text" class="form-control" id="inputAddress" value="<?php echo e($user->school->npsn); ?>"
                            disabled>
                    </div>
                </form>

                <h5 class="card-title">Data Berkas</h5>
                <div class="foto-berkas">
                    <div class="col-sm-12 col-md-6">
                        <p>Foto Siswa</p>
                        <?php if(!empty($user->foto_siswa)): ?>
                            <a href="<?php echo e(asset($user->foto_siswa)); ?>" target="_blank" rel="noopener noreferrer">
                                <img src="<?php echo e(asset($user->foto_siswa)); ?>" alt="foto_siswa" class="foto_siswa">
                            </a>
                        <?php else: ?>
                            <div class="no-image">
                                <p>Belum upload foto diri</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <p>Foto Kartu Keluarga</p>
                        <?php if(!empty($user->foto_akte)): ?>
                            <a href="<?php echo e(asset($user->foto_akte)); ?>" target="_blank" rel="noopener noreferrer">
                                <img src="<?php echo e(asset($user->foto_akte)); ?>" alt="foto_siswa" class="foto_siswa">
                            </a>
                        <?php else: ?>
                            <div class="no-image">
                                <p>Belum upload foto Kartu Keluarga</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <h5 class="card-title">Data Orang Tua</h5>
                <form class="row g-3">
                    <div class="col-sm-12 col-md-6">
                        <label for="inputNanme4" class="form-label">Nama Lengkap Ayah</label>
                        <input type="text" class="form-control" id="inputNanme4"
                            value="<?php echo e($user->father->nama_lengkap_ayah); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputEmail4" class="form-label">Nama Lengkap Ibu</label>
                        <input type="text" class="form-control" value="<?php echo e($user->mother->nama_lengkap_ibu); ?>"
                            disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputPassword4" class="form-label">NIK Ayah</label>
                        <input type="text" class="form-control" value="<?php echo e($user->father->nik_ayah); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">NIK Ibu</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->mother->nik_ibu); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Pekerjeaan Ayah</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->father->pekerjaan_ayah); ?> " disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Pekerjaan Ibu</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->mother->pekerjaan_ibu); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Nama Kantor Ayah</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->father->nama_kantor_ayah); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Nama Kantor Ibu</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->mother->nama_kantor_ibu); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Penghasilan Ayah</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->father->penghasilan_ayah); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Penghasilan Ibu</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->mother->penghasilan_ibu); ?>" disabled>
                    </div>
                </form>

                <h5 class="card-title">Data Rumah</h5>
                <form class="row g-3">
                    <div class="col-sm-12 col-md-6">
                        <label for="inputNanme4" class="form-label">Alamat</label>
                        <input type="text" class="form-control" id="inputNanme4"
                            value="<?php echo e($user->father->nama_lengkap_ayah); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputEmail4" class="form-label">Kode Pos</label>
                        <input type="text" class="form-control" value="<?php echo e($user->mother->nama_lengkap_ibu); ?>"
                            disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputPassword4" class="form-label">Nomor KK</label>
                        <input type="text" class="form-control" value="<?php echo e($user->father->nik_ayah); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Telepon Rumah</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->mother->nik_ibu); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Kelurahan</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->father->pekerjaan_ayah); ?> " disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Nomor Telepon</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->mother->pekerjaan_ibu); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Kecamatan</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->father->nama_kantor_ayah); ?>" disabled>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <label for="inputAddress" class="form-label">Kota / Kabupaten</label>
                        <input type="text" class="form-control" id="inputAddress"
                            value="<?php echo e($user->mother->nama_kantor_ibu); ?>" disabled>
                    </div>
                </form>

                <h5 class="card-title">Data Rumah</h5>
                <div class=" overflow-auto">
                    <table class="table table-borderless datatable mt-4">
                        <thead>
                            <tr>
                                <th scope="col">No.</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Sertifikat</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $user->prestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pres): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($pres->prestasi); ?></td>
                                    <td><?php echo e($pres->tingkat); ?></td>
                                    <td class="d-flex">
                                        <a href="<?php echo e(asset($pres->sertifikat)); ?>" target="_blank"
                                            rel="noopener noreferrer">
                                            <i class="bi bi-eye-fill"></i>
                                            Lihat foto
                                        </a>
                                    </td>
                                    <td>
                                        <div>
                                            <form
                                                action="<?php echo e(route('dashboard.data-prestasi.delete', ['id' => $pres->id])); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="badge rounded-pill bg-danger">
                                                    <i class="bi bi-trash"></i>
                                                    Hapus
                                                </button>
                                            </form>
                                        </div>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Pemetaan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('verifikasi', ['user' => $user->id])); ?>" method="POST" class="row g-3">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label for="">Tanggal</label>
                            <input type="date" name="pemetaan_date" id="" class="form-control" required>
                        </div>
                        <div>
                            <label for="">Jam</label>
                            <input type="time" name="pemetaan_time" id="" class="form-control" required>
                        </div>
                        <div>
                            <label for="">Nama Verifikator</label>
                            <input type="text" name="name_validator" id="" class="form-control" required>
                        </div>
                        <div class=" d-grid">
                            <button type="submit" class="btn btn-primary btn-block">Verifikasi</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Developments\PROGRAMMING\_project-2023\ppdb-min\server\resources\views/detail-profile.blade.php ENDPATH**/ ?>