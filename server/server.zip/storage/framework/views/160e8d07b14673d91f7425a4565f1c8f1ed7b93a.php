<?php $__env->startSection('container'); ?>
    <div class="col-12">

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <?php if($user->jalur): ?>
                    <h5 class="card-title mt-3 mb-0">Data Alamat</h5>
                    <p className="text-gray-500 font-medium ">
                        Lengkapi data dibawah, Jika terdapat <span className="text-red-600">(*)</span> maka wajib diisi
                    </p>
                    <form class="row g-3" action="<?php echo e(route('dashboard.data-alamat.update')); ?>" method="POST">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="col-sm-12 col-md-6">
                            <label for="no_kk" class="form-label">No. Kartu Keluarga</label>
                            <input type="text" class="form-control" name="no_kk" value="<?php echo e($user->address->no_kk); ?>" placeholder="ex: 36382547900755512">
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label for="kelurahan" class="form-label">Kelurahan</label>
                            <input type="text" class="form-control" name="kelurahan"
                                value="<?php echo e($user->address->kelurahan); ?>" placeholder="ex: Sawojajar">
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label for="kecamatan" class="form-label">Kecamatan</label>
                            <input type="text" class="form-control" value="<?php echo e($user->address->kecamatan); ?>"
                                name="kecamatan" placeholder="ex: Pagak">
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label for="kota_kab" class="form-label">Kota / Kabupaten</label>
                            <input type="text" class="form-control" name="kota_kab"
                                value="<?php echo e($user->address->kota_kab); ?>" placeholder="ex: Malang">
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label for="kode_pos" class="form-label">Kode Pos</label>
                            <input type="text" class="form-control" value="<?php echo e($user->address->kode_pos); ?>"
                                name="kode_pos" placeholder="ex: 65139">
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label for="jarak_rumah" class="form-label">Jarak Rumah ke MIN 1 Kota Malang</label>
                            <select class="form-select" name="jarak_rumah">
                                <?php $__currentLoopData = $jarak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jrk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($jrk == $user->jarak_rumah): ?>
                                        <option value="<?php echo e($jrk); ?>" selected> <?php echo e($jrk); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($jrk); ?>"> <?php echo e($jrk); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary mt-4 py-2 rounded-2">
                            Simpan Perubahan
                        </button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-danger mt-4 mb-0" role="alert">
                        <i class="bi bi-exclamation-circle"></i>
                        Silahkan memilih jalur pendaftaran terlebih dahulu! <a href="<?php echo e(route('dashboard.siswa')); ?>">Klik
                            disini</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Developments\PROGRAMMING\_project-2023\ppdb-min\server\resources\views/student/data-alamat.blade.php ENDPATH**/ ?>