<?php $__env->startSection('container'); ?>
    <div class="col-12">

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <?php if($user->jalur): ?>
                    <h5 class="card-title mt-3 mb-0">Data Orang tua</h5>
                    <p className="text-gray-500 font-medium ">
                        Lengkapi data dibawah, Jika terdapat <span className="text-red-600">(*)</span> maka wajib diisi
                    </p>
                    <form class="row g-3" action="<?php echo e(route('dashboard.data-ortu.update')); ?>" method="POST">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="col-sm-12 col-md-6">
                            <label for="nama_lengkap_ayah" class="form-label">Nama Lengkap Ayah *</label>
                            <input type="text" class="form-control" name="nama_lengkap_ayah" placeholder="ex: Budi Setyawan"
                                value="<?php echo e($father->nama_lengkap_ayah); ?>">
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label for="nama_lengkap_ibu" class="form-label">Nama Lengkap Ibu *</label>
                            <input type="text" class="form-control" value="<?php echo e($mother->nama_lengkap_ibu); ?>"
                                name="nama_lengkap_ibu" placeholder="ex: Putri Tjisaka">
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label for="nik_ayah" class="form-label">NIK Ayah *</label>
                            <input type="text" class="form-control" name="nik_ayah" value="<?php echo e($father->nik_ayah); ?>" placeholder="ex: 213521376182367">
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label for="nik_ibu" class="form-label">NIK Ibu *</label>
                            <input type="text" class="form-control" value="<?php echo e($mother->nik_ibu); ?>" name="nik_ibu" placeholder="ex: 123721596236">
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label for="pekerjaan_ayah" class="form-label">Pekerjaan Ayah *</label>
                            <input type="text" class="form-control"
                                value="<?php echo e($father->pekerjaan_ayah); ?>" name="pekerjaan_ayah" placeholder="ex: Petani">
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label for="pekerjaan_ibu" class="form-label">Pekerjaan Ibu *</label>
                            <input type="text" class="form-control"
                                value="<?php echo e($mother->pekerjaan_ibu); ?>" name="pekerjaan_ibu" placeholder="ex: Ibu rumah tangga">
                        </div>

                        <div class="col-sm-12 col-md-6">
                            <label for="nama_kantor_ayah" class="form-label">Nama Kantor Ayah *</label>
                            <input type="text" class="form-control"
                                value="<?php echo e($father->nama_kantor_ayah); ?>" name="nama_kantor_ayah" placeholder="ex: Sawah">
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label for="nama_kantor_ibu" class="form-label">Nama Kantor Ibu *</label>
                            <input type="text" class="form-control"
                                value="<?php echo e($mother->nama_kantor_ibu); ?>" name="nama_kantor_ibu" placeholder="ex: Rumah">
                        </div>

                        <div class="col-sm-12 col-md-6">
                            <label for="penghasilan_ayah" class="form-label">Penghasilan Ayah *</label>
                            <select class="form-select" name="penghasilan_ayah">
                                <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item === $user->penghasilan_ayah): ?>
                                        <option value="<?php echo e($item); ?>" selected> <?php echo e($item); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($item); ?>"> <?php echo e($item); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-sm-12 col-md-6">
                            <label for="penghasilan_ibu" class="form-label">Penghasilan Ibu *</label>
                            <select class="form-select" name="penghasilan_ibu">
                                <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item === $user->penghasilan_ibu): ?>
                                        <option value="<?php echo e($item); ?>" selected> <?php echo e($item); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($item); ?>"> <?php echo e($item); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-sm-12 col-md-6">
                            <label for="no_telp_ayah" class="form-label">No. Telp Ayah *</label>
                            <input type="text" class="form-control"
                                value="<?php echo e($father->no_telp_ayah); ?>" name="no_telp_ayah" placeholder="ex: 08213526135">
                        </div>

                        <div class="col-sm-12 col-md-6">
                            <label for="no_telp_ibu" class="form-label">No. Telp Ibu *</label>
                            <input type="text" class="form-control"
                                value="<?php echo e($mother->no_telp_ibu); ?>" name="no_telp_ibu" placeholder="ex: 08213526135">
                        </div>

                        <button type="submit" class="btn btn-primary mt-4 py-2 rounded-2">
                            Simpan Perubahan
                        </button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-danger mt-4 mb-0" role="alert">
                        <i class="bi bi-exclamation-circle"></i>
                        Silahkan memilih jalur pendaftaran terlebih dahulu! <a href="<?php echo e(route('dashboard.siswa')); ?>">Klik
                            disini</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Developments\PROGRAMMING\_project-2023\ppdb-min\server\resources\views/student/data-ortu.blade.php ENDPATH**/ ?>