<?php $__env->startSection('container'); ?>
    <div class="col-12">

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <?php if(auth()->user()->jalur): ?>
                    <?php if(auth()->user()->jalur === 'reguler' || auth()->user()->jalur === 'prestasi'): ?>
                        <h5 class="card-title mt-3">Upload Sertifikat Prestasi</h5>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#staticBackdrop">
                            <i class="bi bi-plus-square"></i>
                            Tambah prestasi
                        </button>
                    <?php elseif(auth()->user()->jalur === 'tahfidz'): ?>
                        <h5 class="card-title mt-3">Upload sertifikat tahfidz</h5>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#staticBackdrop1">
                            <i class="bi bi-cloud-upload"></i>
                            Upload sertifikat
                        </button>
                    <?php else: ?>
                        <h5 class="card-title mt-3">Upload surat keterangan dari Kelurahan</h5>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#staticBackdrop2">
                            <i class="bi bi-cloud-upload"></i>
                            Upload
                        </button>
                    <?php endif; ?>

                    <div class=" overflow-auto">
                        <table class="table table-borderless datatable mt-4">
                            <thead>
                                <tr>
                                    <th scope="col">No.</th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">Sertifikat</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($prestasi) > 0): ?>
                                    <?php $__currentLoopData = $prestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pres): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                                            <td><?php echo e($pres->prestasi); ?></td>
                                            <td class="d-flex">
                                                <a href="<?php echo e(asset($pres->sertifikat)); ?>" target="_blank"
                                                    rel="noopener noreferrer">
                                                    <i class="bi bi-eye-fill"></i>
                                                    Lihat foto
                                                </a>
                                            </td>
                                            <td>
                                                <div>
                                                    <form
                                                        action="<?php echo e(route('dashboard.data-prestasi.delete', ['id' => $pres->id])); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="badge rounded-pill bg-danger">
                                                            <i class="bi bi-trash"></i>
                                                            Hapus
                                                        </button>
                                                    </form>
                                                </div>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td>Belum ada data</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-danger mt-4 mb-0" role="alert">
                        <i class="bi bi-exclamation-circle"></i>
                        Silahkan memilih jalur pendaftaran terlebih dahulu! <a href="<?php echo e(route('dashboard.siswa')); ?>">Klik
                            disini</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal1 -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Tambah Prestasi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="row g-3" action="<?php echo e(route('dashboard.data-prestasi.store')); ?>" method="post"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="col-12">
                            <label for="inputNanme4" class="form-label">Prestasi</label>
                            <input type="text" class="form-control" name="prestasi"
                                placeholder="ex: Juara 1 lomba olimpiade matematika">
                        </div>
                        <div class="col-12">
                            <label for="foto_siswa" class="form-label">Sertifikat</label>
                            <input class="form-control" type="file" id="sertifikat" name="sertifikat">
                        </div>
                        <button type="submit" class="btn btn-primary mt-4 py-2 rounded-2">
                            Tambah
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="staticBackdrop1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Upload Sertifikat Tahfidz</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="row g-3" action="<?php echo e(route('dashboard.data-prestasi.store')); ?>" method="post"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="col-12">
                            <label for="inputNanme4" class="form-label">Nama Sertifikat</label>
                            <input type="text" class="form-control" name="prestasi"
                                placeholder="ex: Sertifikat tahfidz pondok ...">
                        </div>
                        <div class="col-12">
                            <label for="foto_siswa" class="form-label">Sertifikat</label>
                            <input class="form-control" type="file" id="sertifikat" name="sertifikat">
                        </div>
                        <button type="submit" class="btn btn-primary mt-4 py-2 rounded-2">
                            Upload
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="staticBackdrop2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Upload Surat Keterangan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="row g-3" action="<?php echo e(route('dashboard.data-prestasi.store')); ?>" method="post"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="col-12">
                            <label for="inputNanme4" class="form-label">Prestasi</label>
                            <input type="text" class="form-control" name="prestasi"
                                placeholder="ex: Surat keterangan">
                        </div>
                        <div class="col-12">
                            <label for="foto_siswa" class="form-label">Sertifikat</label>
                            <input class="form-control" type="file" id="sertifikat" name="sertifikat">
                        </div>
                        <button type="submit" class="btn btn-primary mt-4 py-2 rounded-2">
                            Upload
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Developments\PROGRAMMING\_project-2023\ppdb-min\server\resources\views/student/data-prestasi.blade.php ENDPATH**/ ?>